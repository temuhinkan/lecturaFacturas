import flet as ft
def vista_historico():
    return ft.Text("Pantalla Histórico (En construcción)", size=30)
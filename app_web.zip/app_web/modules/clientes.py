import flet as ft
import database

def vista_clientes():
    # --- Estado y Refs ---
    lista_clientes = ft.Ref[ft.ListView]()
    form_cliente = ft.Ref[ft.Column]()
    
    # --- Funciones de Lógica ---
    def cargar_detalle_cliente(cliente_data):
        form_cliente.current.controls = [
            ft.Text(f"Configuración de {cliente_data['nombre']}", size=20, weight="bold"),
            ft.TextField(label="CIF / NIF", value=cliente_data['cif']),
            ft.Divider(),
            ft.Text("Reglas de Extracción", weight="bold"),
            ft.Dropdown(
                label="Extractor Asignado",
                options=[
                    ft.dropdown.Option("Genérico"),
                    ft.dropdown.Option("Autodoc"),
                    ft.dropdown.Option("Stellantis"),
                ],
                value=cliente_data['extractor_default'] or "Genérico"
            ),
            ft.TextField(
                label="Palabras Clave (Separadas por comas)",
                helper_text="Si la factura contiene estas palabras, se usará este extractor.",
                value=cliente_data['palabras_clave']
            ),
            ft.ElevatedButton("Guardar Cambios Cliente", icon=ft.icons.SAVE, bgcolor="blue", color="white")
        ]
        form_cliente.current.update()

    # --- UI Components ---
    col_izquierda = ft.Column([
        ft.Text("Listado de Clientes", size=20, weight="bold"),
        ft.TextField(label="Buscar cliente...", prefix_icon=ft.icons.SEARCH),
        ft.ListView(ref=lista_clientes, expand=True, spacing=10)
    ], expand=1)

    col_derecha = ft.Column(ref=form_cliente, expand=2, spacing=20)

    # Simulación de carga (aquí usarás database.fetch_all_clients)
    clientes_demo = [
        {"nombre": "Autodoc España", "cif": "B12345678", "extractor_default": "Autodoc", "palabras_clave": "Autodoc, SE"},
        {"nombre": "Desguaces Eduardo", "cif": "A98765432", "extractor_default": "Genérico", "palabras_clave": "Eduardo, Desguace"}
    ]

    for c in clientes_demo:
        lista_clientes.current.controls.append(
            ft.ListTile(
                title=ft.Text(c['nombre']),
                subtitle=ft.Text(f"CIF: {c['cif']}"),
                leading=ft.Icon(ft.icons.BUSINESS),
                on_click=lambda e, data=c: cargar_detalle_cliente(data)
            )
        )

    return ft.Row([
        ft.Container(col_izquierda, padding=10, border=ft.border.all(1, "grey100"), border_radius=10),
        ft.VerticalDivider(),
        ft.Container(col_derecha, padding=20)
    ], expand=True)
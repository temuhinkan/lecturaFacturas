import flet as ft

def crear_card(titulo, valor, icono, color):
    return ft.Card(
        content=ft.Container(
            content=ft.Column([
                ft.ListTile(
                    leading=ft.Icon(icono, color=color, size=40), # El icono aquí ya acepta strings
                    title=ft.Text(valor, size=30, weight="bold"),
                    subtitle=ft.Text(titulo),
                ),
            ]),
            padding=10,
        ),
        width=200,
    )

def vista_resumen():
    return ft.Column([
        ft.Text("Resumen de Actividad", size=25, weight="bold"),
        ft.Row([
            # CAMBIO: Usamos strings en lugar de ft.icons.NOMBRE
            crear_card("Por Validar", "12", "pending_actions", "orange"),
            crear_card("Vehículos", "5", "directions_car", "blue"),
            crear_card("Gastos Mes", "1.250€", "payments", "green"),
        ], wrap=True),
    ])
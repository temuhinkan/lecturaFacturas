import flet as ft
import logic
import database
from PDFEngineWeb import PDFEngineWeb

def vista_validar():
    engine = PDFEngineWeb()
    # Referencia para almacenar la ruta del archivo que se está editando actualmente
    ruta_activa = ft.Ref[ft.Text]() 

    # --- ELEMENTOS DE LA INTERFAZ ---
    visor_img = ft.Image(src_base64="", fit=ft.ImageFit.CONTAIN)
    lista_facturas = ft.ListView(expand=True, spacing=10)
    
    # Campos del formulario (Datos extraídos)
    txt_emisor = ft.TextField(label="Emisor / Proveedor", expand=True)
    txt_fecha = ft.TextField(label="Fecha Factura", expand=True)
    txt_total = ft.TextField(label="Total Importe (€)", expand=True)
    txt_matricula_ocr = ft.TextField(label="Matrícula Detectada por OCR", expand=True, read_only=True, color="blue")
    
    # Selector de vehículo del Stock
    dropdown_stock = ft.Dropdown(
        label="Vincular a Vehículo (Stock)",
        hint_text="Seleccione un coche para asignar el gasto",
        expand=True,
    )

    txt_log = ft.Text(value="Seleccione una factura de la lista izquierda", color="grey", size=12)

    # --- LÓGICA DE FUNCIONAMIENTO ---

    def cargar_datos_stock():
        """Carga los vehículos reales de la base de datos en el dropdown."""
        try:
            vehiculos = database.get_all_vehiculos()
            dropdown_stock.options = [
                ft.dropdown.Option(key=str(v['id']), text=f"{v['matricula']} - {v['marca']} {v['modelo']}")
                for v in vehiculos
            ]
            dropdown_stock.update()
        except Exception as e:
            print(f"Error cargando stock: {e}")

    def cargar_factura_seleccionada(path):
        """Carga el PDF, ejecuta el OCR y busca coincidencias con el stock."""
        ruta_activa.current.value = path
        
        # 1. Visualizar PDF
        engine.load_document(path)
        img_b64, w, h = engine.get_page_image_b64()
        visor_img.src_base64 = img_b64
        visor_img.width = w
        visor_img.height = h
        
        # 2. Ejecutar extracción lógica (tu logic.py)
        # res_list tiene: [tipo, fecha, num_factura, emisor, cif, cliente, cif_c, modelo, matricula, importe...]
        res_list, debug_log = logic.extraer_datos(path)
        
        # 3. Rellenar campos del formulario
        txt_fecha.value = res_list[1]
        txt_emisor.value = res_list[3]
        txt_matricula_ocr.value = res_list[8]
        txt_total.value = str(res_list[9])
        txt_log.value = f"Análisis finalizado: {res_list[3]}"

        # 4. AUTO-SELECCIÓN POR MATRÍCULA
        dropdown_stock.value = None # Reset
        matricula_detectada = str(res_list[8]).strip().upper() if res_list[8] else ""
        
        if matricula_detectada:
            for opcion in dropdown_stock.options:
                # Si la matrícula detectada está dentro del texto de la opción (que tiene Matrícula - Modelo)
                if matricula_detectada in opcion.text.upper():
                    dropdown_stock.value = opcion.key
                    txt_log.value += f" | 🚗 Coincidencia con stock: {opcion.text}"
                    break
        
        # Actualizar toda la vista
        visor_img.update()
        txt_fecha.update()
        txt_emisor.update()
        txt_matricula_ocr.update()
        txt_total.update()
        dropdown_stock.update()
        txt_log.update()

    def guardar_validacion(e):
        """Guarda los cambios, marca como validada y vincula el gasto al coche."""
        if not ruta_activa.current.value:
            return

        try:
            path = ruta_activa.current.value
            
            # 1. Actualizar la factura en la tabla principal
            database.update_invoice_field(path, "is_validated", 1)
            database.update_invoice_field(path, "emisor", txt_emisor.value)
            database.update_invoice_field(path, "importe", float(txt_total.value.replace(',','.')))

            # 2. Si hay un vehículo seleccionado, crear el registro de gasto
            if dropdown_stock.value:
                database.vincular_gasto_vehiculo(
                    vehiculo_id=int(dropdown_stock.value),
                    factura_path=path,
                    concepto=f"Factura: {txt_emisor.value}",
                    importe=float(txt_total.value.replace(',','.'))
                )
            
            e.page.snack_bar = ft.SnackBar(ft.Text("✅ Factura guardada y vinculada al vehículo"))
            e.page.snack_bar.open = True
            refrescar_lista_pendientes()
            e.page.update()
            
        except Exception as ex:
            txt_log.value = f"Error al guardar: {ex}"
            txt_log.update()

    def refrescar_lista_pendientes():
        """Lee la BBDD y muestra solo facturas no validadas."""
        facturas = database.fetch_all_invoices()
        lista_facturas.controls.clear()
        for f in facturas:
            # Filtramos por las que no están validadas (is_validated = 0)
            if f.get('is_validated') == 0:
                lista_facturas.controls.append(
                    ft.ListTile(
                        leading=ft.Icon(ft.icons.PICTURE_AS_PDF, color="red"),
                        title=ft.Text(f['file_name']),
                        subtitle=ft.Text(f"Pendiente de validar"),
                        on_click=lambda e, p=f['path']: cargar_factura_seleccionada(p)
                    )
                )
        lista_facturas.update()

    # --- ESTRUCTURA VISUAL (LAYOUT) ---
    return ft.Row([
        # PANEL IZQUIERDO: LISTA
        ft.Container(
            content=ft.Column([
                ft.Text("Facturas Pendientes", size=18, weight="bold"),
                lista_facturas,
                ft.ElevatedButton("Refrescar Lista", icon=ft.icons.REFRESH, on_click=lambda _: refrescar_lista_pendientes())
            ]),
            width=280, padding=10, bgcolor="#f5f5f5", border_radius=10
        ),
        
        # PANEL CENTRAL: VISOR PDF
        ft.Container(
            content=ft.Column([
                ft.Text(ref=ruta_activa, visible=False), # Campo oculto para la ruta
                ft.Card(content=ft.Container(visor_img, padding=5), elevation=3)
            ], scroll=ft.ScrollMode.ALWAYS),
            expand=True, padding=10
        ),
        
        # PANEL DERECHO: FORMULARIO
        ft.Container(
            content=ft.Column([
                ft.Text("Validación y Vínculo", size=20, weight="bold"),
                ft.Divider(),
                txt_emisor,
                txt_fecha,
                txt_total,
                ft.Divider(),
                ft.Text("Relación con Stock", weight="bold", color="blue"),
                txt_matricula_ocr,
                dropdown_stock,
                ft.Divider(),
                txt_log,
                ft.ElevatedButton(
                    "VALIDAR Y GUARDAR", 
                    icon=ft.icons.SAVE, 
                    bgcolor="green", 
                    color="white",
                    height=50,
                    on_click=guardar_validacion
                )
            ], scroll=ft.ScrollMode.AUTO),
            width=320, padding=20
        )
    ], expand=True, on_mount=lambda _: [cargar_datos_stock(), refrescar_lista_pendientes()])
import flet as ft
import database

def vista_stock():
    # --- Referencias ---
    tabla_stock = ft.Ref[ft.DataTable]()
    detalle_gastos = ft.Ref[ft.Column]()
    txt_total_inversion = ft.Ref[ft.Text]()

    def mostrar_detalle(vehiculo):
        # Simulamos obtener gastos de la BBDD vinculados a este coche
        gastos = [
            {"concepto": "Compra inicial", "monto": vehiculo['precio_compra']},
            {"concepto": "Kit de Distribución (Factura 123)", "monto": 450.00},
            {"concepto": "Limpieza Integral", "monto": 120.00},
        ]
        
        total = sum(g['monto'] for g in gastos)
        
        detalle_gastos.current.controls = [
            ft.Text(f"Historial de Gastos: {vehiculo['marca']} {vehiculo['modelo']}", size=18, weight="bold"),
            ft.DataTable(
                columns=[ft.DataColumn(ft.Text("Concepto")), ft.DataColumn(ft.Text("Importe"))],
                rows=[ft.DataRow(cells=[ft.DataCell(ft.Text(g['concepto'])), ft.DataCell(ft.Text(f"{g['monto']} €"))]) for g in gastos]
            )
        ]
        txt_total_inversion.current.value = f"Inversión Total: {total} €"
        txt_total_inversion.current.update()
        detalle_gastos.current.update()

    # --- UI ---
    col_lista = ft.Column([
        ft.Row([
            ft.Text("Inventario de Vehículos", size=24, weight="bold"),
            ft.ElevatedButton("Añadir Coche", icon=ft.icons.ADD, bgcolor="blue", color="white")
        ], alignment="spaceBetween"),
        ft.DataTable(
            ref=tabla_stock,
            columns=[
                ft.DataColumn(ft.Text("Matrícula")),
                ft.DataColumn(ft.Text("Vehículo")),
                ft.DataColumn(ft.Text("Estado")),
            ],
            rows=[
                # Ejemplo de fila cargada
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text("1234-LMN")),
                        ft.DataCell(ft.Text("Audi A3 2019")),
                        ft.DataCell(ft.Badge(content=ft.Text("Disponible"), bgcolor="green")),
                    ],
                    on_select_changed=lambda _: mostrar_detalle({"marca":"Audi", "modelo":"A3", "precio_compra": 12000})
                )
            ]
        )
    ], expand=2)

    col_detalle = ft.Container(
        content=ft.Column([
            ft.Text("Selecciona un vehículo para ver los gastos asociados", color="grey"),
            ft.Column(ref=detalle_gastos),
            ft.Divider(),
            ft.Text(ref=txt_total_inversion, size=20, weight="bold", color="blue")
        ]),
        expand=1, padding=20, bgcolor="#f9f9f9", border_radius=10
    )

    return ft.Row([col_lista, ft.VerticalDivider(), col_detalle], expand=True)
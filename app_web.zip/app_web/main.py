import flet as ft
from modules import dashboard, validador, historico, clientes, stock
import database

def main(page: ft.Page):
    page.title = "ERP Compra-Venta de Vehículos"
    page.theme_mode = ft.ThemeMode.LIGHT
    
    # 1. Registro del FilePicker (Debe ser lo primero)
    file_picker = ft.FilePicker()
    page.overlay.append(file_picker) 
    
    # Inicializar Base de Datos
    database.setup_database()

    container_principal = ft.Container(expand=True, padding=20)

    def cambiar_pantalla(e):
        index = e.control.selected_index
        if index == 0:
            container_principal.content = dashboard.vista_resumen()
        elif index == 1:
            container_principal.content = validador.vista_validar()
        elif index == 2:
            container_principal.content = historico.vista_historico()
        elif index == 3:
            container_principal.content = clientes.vista_clientes()
        elif index == 4:
            container_principal.content = stock.vista_stock()
        page.update()

    # --- NAVEGACIÓN ---
    sidebar = ft.NavigationRail(
        selected_index=0,
        label_type=ft.NavigationRailLabelType.ALL,
        destinations=[
            ft.NavigationRailDestination(icon="dashboard", label="Resumen"),
            ft.NavigationRailDestination(icon="fact_check", label="Validar"),
            ft.NavigationRailDestination(icon="history", label="Histórico"),
            ft.NavigationRailDestination(icon="people", label="Clientes"),
            ft.NavigationRailDestination(icon="directions_car", label="Stock"),
        ],
        on_change=cambiar_pantalla,
    )

    # Botón flotante corregido
    page.floating_action_button = ft.FloatingActionButton(
        icon="upload_file",
        on_click=lambda _: file_picker.pick_files(allow_multiple=True, allowed_extensions=["pdf"])
    )

    container_principal.content = dashboard.vista_resumen()

    page.add(
        ft.Row([sidebar, ft.VerticalDivider(width=1), container_principal], expand=True)
    )

if __name__ == "__main__":
    # Usamos 'run' para eliminar el aviso de Deprecation de una vez
    ft.app(main)